id,
landing_region_id,		
reseller_id,
company_id,


name,
status,	--o

country,
region_name,


created_at,		
updated_at,	
deleted_at,		


checking_status,


from `floranow.erp_prod.warehouses` as w