id,
flori_product_id,
flori_application_id,
flori_main_group_id,
flori_sub_group_id,
supplier_id,
reference_id,
source_id,
stock_id,


name,
color,
color_code,

flori_product_name,
flori_application_name,
flori_main_group_name,
flori_sub_group_name,
mask,
mapping,
properties,

created_at,
updated_at,
deleted_at,

custom_properties,