id,
warehouse_id,
section_id,


created_at,
updated_at,
deleted_at,


section, --A1,A2,A3
barcode,
status, --null, 2
label, -- A,B,C,D,E,F,G



number,
name,


from `floranow.erp_prod.locations` as l