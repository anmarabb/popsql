updated_at,
created_at,

id,
warehouse_id,

warehouse_checking_status,	--null	
name, -- A1, A2, B1, B2, ...
checking_status,	--null	


from `floranow.erp_prod.sections` as se