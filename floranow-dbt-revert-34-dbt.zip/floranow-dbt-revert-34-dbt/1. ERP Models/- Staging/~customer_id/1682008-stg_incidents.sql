SELECT


FROM
  `floranow.erp_prod.product_incidents` AS pi
GROUP BY
  customer_id