--date
PrintedAtTest,  --HORDERKP.VERTREKDAG
invoice_date,	--BETAAL.BETDAT	


delivery_date,		


FinancialAdmin,

client_id,
client_name,	

invoice_detail_id,
drop_id,
samer_client_name,	
client_city,	
client_country,	
client_category,	
supplier_id,	
supplier_name_row,	
supplier_name,	
supplier_region,	
invoice_id,
item_code,	
item_name,	
samer_item_category,	
item_s1,
item_category,	
total_fob_price,
unit_fob_price,
total_lande_price,
unit_lande_price,
total_revenue,
invoice_type,	
item_quantity,
unit_margin,
unit_selling_price,
row_dd_ordnr,
delivery_date_id,
samer_account_executive,	
row_client_city,	
row_account_executive,	
team_leader,