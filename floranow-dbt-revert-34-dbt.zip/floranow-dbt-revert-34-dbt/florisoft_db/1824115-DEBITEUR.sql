SELECT 
FINADMIN as financial_administration_id,
DEBNAAM as debtor_name, 
DEBKEY,
DEBNR as debtor_number,
DEBPLAATS as City,
FROM `floranow.florisoft_db.DEBITEUR`